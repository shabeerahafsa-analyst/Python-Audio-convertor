import os
from pydub import AudioSegment

# ---- Customize these ----
lesson_name = "SBlends"
slide_name = "Slide3"
# --------------------------

input_folder = "input_mp3"
output_folder = "output_ogg"

os.makedirs(output_folder, exist_ok=True)

for filename in os.listdir(input_folder):
    if filename.lower().endswith(".mp3"):
        input_path = os.path.join(input_folder, filename)

        # Remove extension and replace spaces with underscores
        base_name = os.path.splitext(filename)[0].replace(" ", "_")

        # Create new filename with lesson + slide + original name
        output_filename = f"{lesson_name}_{slide_name}_{base_name}.ogg"
        output_path = os.path.join(output_folder, output_filename)

        print(f"Processing: {input_path}")

        # Load MP3 file
        audio = AudioSegment.from_mp3(input_path)

        # Set sample rate = 48 kHz and sample width = 24 bit
        audio = audio.set_frame_rate(48000).set_sample_width(3)

        # Export as OGG
        audio.export(output_path, format="ogg")

        print(f"Converted to: {output_filename}")

print("✅ Batch conversion completed!")
