import os
from pydub import AudioSegment
import re

# ---- Customize this ----
lesson_name = "SBlends"
# ------------------------

input_folder = "input_mp3"
output_folder = "output_ogg"

os.makedirs(output_folder, exist_ok=True)

for filename in os.listdir(input_folder):
    if filename.lower().endswith(".mp3"):
        input_path = os.path.join(input_folder, filename)

        # Extract slide name from filename (pattern: Slide+number)
        match = re.search(r'(Slide\d+)', filename, re.IGNORECASE)
        if match:
            slide_name = match.group(1)
        else:
            slide_name = "Slide0"  # fallback if slide not found

        # Clean filename: replace spaces
        base_name = os.path.splitext(filename)[0].replace(" ", "_")

        # Build final output filename
        output_filename = f"{lesson_name}_{slide_name}_{base_name}.ogg"
        output_path = os.path.join(output_folder, output_filename)

        print(f"Processing: {input_path}")

        audio = AudioSegment.from_mp3(input_path)
        audio = audio.set_frame_rate(48000).set_sample_width(3)

        audio.export(output_path, format="ogg")

        print(f"Converted to: {output_filename}")

print("✅ Conversion completed!")
